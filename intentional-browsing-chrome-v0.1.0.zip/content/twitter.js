// src/content/router.ts
var Router = class {
  listeners = /* @__PURE__ */ new Set();
  lastUrl = "";
  originalPushState = null;
  originalReplaceState = null;
  popstateHandler = null;
  init() {
    this.lastUrl = window.location.href;
    this.patchHistory();
    this.popstateHandler = () => this.handleNavigation();
    window.addEventListener("popstate", this.popstateHandler);
    return this.lastUrl;
  }
  patchHistory() {
    this.originalPushState = history.pushState;
    this.originalReplaceState = history.replaceState;
    history.pushState = (...args) => {
      this.originalPushState.apply(history, args);
      this.handleNavigation();
    };
    history.replaceState = (...args) => {
      this.originalReplaceState.apply(history, args);
      this.handleNavigation();
    };
  }
  /**
   * Handle a navigation event
   */
  handleNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === this.lastUrl) {
      return;
    }
    this.lastUrl = currentUrl;
    for (const callback of this.listeners) {
      try {
        callback(currentUrl);
      } catch (error) {
        console.error("[IntentionalBrowsing] Router callback error:", error);
      }
    }
  }
  /**
   * Register a callback to be called when the URL changes
   */
  onLocationChange(callback) {
    this.listeners.add(callback);
  }
  /**
   * Remove a previously registered callback
   */
  removeListener(callback) {
    this.listeners.delete(callback);
  }
  /**
   * Get the current URL
   */
  getCurrentUrl() {
    return this.lastUrl || window.location.href;
  }
  /**
   * Redirect to a new URL
   */
  redirect(url) {
    window.location.href = url;
  }
  destroy() {
    if (this.originalPushState) {
      history.pushState = this.originalPushState;
    }
    if (this.originalReplaceState) {
      history.replaceState = this.originalReplaceState;
    }
    if (this.popstateHandler) {
      window.removeEventListener("popstate", this.popstateHandler);
    }
    this.listeners.clear();
  }
};
var routerInstance = null;
function getRouter() {
  if (!routerInstance) {
    routerInstance = new Router();
  }
  return routerInstance;
}

// src/content/base.ts
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function checkCurrentUrl() {
  const response = await sendMessage({
    type: "CHECK_URL",
    payload: window.location.href
  });
  if (response.success && response.data) {
    return response.data;
  }
  return { shouldBlock: false, mode: "allow" };
}
var PlatformContentScript = class {
  router;
  observer = null;
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
    this.router = getRouter();
  }
  /**
   * Initialize the content script
   */
  async init() {
    console.log(`[IntentionalBrowsing] Initializing ${this.platformId} content script`);
    this.router.init();
    const decision = await checkCurrentUrl();
    if (decision.shouldBlock) {
      if (decision.mode === "soft") {
        this.applySoftBlocks();
      }
    }
    this.router.onLocationChange(async () => {
      const newDecision = await checkCurrentUrl();
      if (newDecision.shouldBlock && newDecision.mode === "soft") {
        this.applySoftBlocks();
      }
    });
    this.setupObserver();
  }
  /**
   * Clean up
   */
  destroy() {
    this.router.destroy();
    if (this.observer) {
      this.observer.disconnect();
    }
  }
};

// src/content/platforms/twitter.ts
var TwitterContentScript = class extends PlatformContentScript {
  hasClickedFollowingTab = false;
  hasHandledRedirect = false;
  constructor() {
    super("twitter");
  }
  async init() {
    await super.init();
    await this.handleRedirect();
    this.router.onLocationChange(async () => {
      this.hasClickedFollowingTab = false;
      this.hasHandledRedirect = false;
      await this.handleRedirect();
    });
  }
  async handleRedirect() {
    const path = window.location.pathname;
    if (path !== "/" && path !== "/home") {
      return;
    }
    if (this.hasHandledRedirect)
      return;
    const response = await sendMessage({ type: "GET_CONFIG" });
    if (!response.success || !response.data)
      return;
    const config = response.data;
    const twitterConfig = config.platforms.twitter;
    if (!config.globalEnabled || !twitterConfig.enabled)
      return;
    this.hasHandledRedirect = true;
    switch (twitterConfig.redirectTarget) {
      case "blocked":
        window.location.href = chrome.runtime.getURL("/ui/blocked.html");
        break;
      case "following-tab":
        this.waitForAndClickFollowingTab();
        break;
      case "/i/chat":
        window.location.href = "https://x.com/messages";
        break;
    }
  }
  waitForAndClickFollowingTab() {
    const maxAttempts = 20;
    let attempts = 0;
    const tryClick = () => {
      attempts++;
      const followingTab = this.findFollowingTab();
      if (followingTab) {
        const isSelected = followingTab.getAttribute("aria-selected") === "true" || followingTab.closest('[aria-selected="true"]') !== null || followingTab.querySelector('[aria-selected="true"]') !== null;
        if (!isSelected) {
          console.log("[IntentionalBrowsing] Clicking Following tab");
          followingTab.click();
        }
        this.hasClickedFollowingTab = true;
        return;
      }
      if (attempts < maxAttempts) {
        setTimeout(tryClick, 200);
      }
    };
    tryClick();
  }
  findFollowingTab() {
    const tabs = document.querySelectorAll('[role="tab"]');
    for (const tab of tabs) {
      if (tab.textContent?.includes("Following")) {
        return tab;
      }
    }
    const headerTabs = document.querySelectorAll('[data-testid="ScrollSnap-List"] a, [role="tablist"] a');
    for (const tab of headerTabs) {
      if (tab.textContent?.includes("Following")) {
        return tab;
      }
    }
    const allLinks = document.querySelectorAll('a[href="/home"]');
    for (const link of allLinks) {
      const text = link.textContent || "";
      if (text.includes("Following")) {
        return link;
      }
    }
    return null;
  }
  applySoftBlocks() {
  }
  setupObserver() {
  }
};
var script = new TwitterContentScript();
script.init().catch(console.error);
//# sourceMappingURL=twitter.js.map

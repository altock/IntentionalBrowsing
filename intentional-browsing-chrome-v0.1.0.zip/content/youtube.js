// src/content/router.ts
var Router = class {
  listeners = /* @__PURE__ */ new Set();
  lastUrl = "";
  originalPushState = null;
  originalReplaceState = null;
  popstateHandler = null;
  init() {
    this.lastUrl = window.location.href;
    this.patchHistory();
    this.popstateHandler = () => this.handleNavigation();
    window.addEventListener("popstate", this.popstateHandler);
    return this.lastUrl;
  }
  patchHistory() {
    this.originalPushState = history.pushState;
    this.originalReplaceState = history.replaceState;
    history.pushState = (...args) => {
      this.originalPushState.apply(history, args);
      this.handleNavigation();
    };
    history.replaceState = (...args) => {
      this.originalReplaceState.apply(history, args);
      this.handleNavigation();
    };
  }
  /**
   * Handle a navigation event
   */
  handleNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === this.lastUrl) {
      return;
    }
    this.lastUrl = currentUrl;
    for (const callback of this.listeners) {
      try {
        callback(currentUrl);
      } catch (error) {
        console.error("[IntentionalBrowsing] Router callback error:", error);
      }
    }
  }
  /**
   * Register a callback to be called when the URL changes
   */
  onLocationChange(callback) {
    this.listeners.add(callback);
  }
  /**
   * Remove a previously registered callback
   */
  removeListener(callback) {
    this.listeners.delete(callback);
  }
  /**
   * Get the current URL
   */
  getCurrentUrl() {
    return this.lastUrl || window.location.href;
  }
  /**
   * Redirect to a new URL
   */
  redirect(url) {
    window.location.href = url;
  }
  destroy() {
    if (this.originalPushState) {
      history.pushState = this.originalPushState;
    }
    if (this.originalReplaceState) {
      history.replaceState = this.originalReplaceState;
    }
    if (this.popstateHandler) {
      window.removeEventListener("popstate", this.popstateHandler);
    }
    this.listeners.clear();
  }
};
var routerInstance = null;
function getRouter() {
  if (!routerInstance) {
    routerInstance = new Router();
  }
  return routerInstance;
}

// src/content/base.ts
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function checkCurrentUrl() {
  const response = await sendMessage({
    type: "CHECK_URL",
    payload: window.location.href
  });
  if (response.success && response.data) {
    return response.data;
  }
  return { shouldBlock: false, mode: "allow" };
}
function hideAllElements(selectorConfig) {
  let hiddenCount = 0;
  const primaries = document.querySelectorAll(selectorConfig.primary);
  primaries.forEach((el) => {
    el.style.display = "none";
    hiddenCount++;
  });
  if (hiddenCount > 0) {
    return hiddenCount;
  }
  for (const fallback of selectorConfig.fallbacks) {
    const elements = document.querySelectorAll(fallback);
    elements.forEach((el) => {
      el.style.display = "none";
      hiddenCount++;
    });
    if (hiddenCount > 0) {
      console.log(`[IntentionalBrowsing] Used fallback selector for ${selectorConfig.description}`);
      return hiddenCount;
    }
  }
  return hiddenCount;
}
function observeAndHide(selectorConfigs, container = document.body) {
  let scheduled = false;
  const hideElements = () => {
    scheduled = false;
    for (const config of selectorConfigs) {
      hideAllElements(config);
    }
  };
  const observer = new MutationObserver(() => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(hideElements);
    }
  });
  observer.observe(container, {
    childList: true,
    subtree: true
  });
  for (const config of selectorConfigs) {
    hideAllElements(config);
  }
  return observer;
}
var PlatformContentScript = class {
  router;
  observer = null;
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
    this.router = getRouter();
  }
  /**
   * Initialize the content script
   */
  async init() {
    console.log(`[IntentionalBrowsing] Initializing ${this.platformId} content script`);
    this.router.init();
    const decision = await checkCurrentUrl();
    if (decision.shouldBlock) {
      if (decision.mode === "soft") {
        this.applySoftBlocks();
      }
    }
    this.router.onLocationChange(async () => {
      const newDecision = await checkCurrentUrl();
      if (newDecision.shouldBlock && newDecision.mode === "soft") {
        this.applySoftBlocks();
      }
    });
    this.setupObserver();
  }
  /**
   * Clean up
   */
  destroy() {
    this.router.destroy();
    if (this.observer) {
      this.observer.disconnect();
    }
  }
};

// src/shared/config.ts
var YOUTUBE_SELECTORS = {
  recommendations: {
    primary: "#secondary ytd-watch-next-secondary-results-renderer",
    fallbacks: ["#related", '[data-testid="related-videos"]'],
    description: "Video recommendations sidebar"
  },
  endCards: {
    primary: ".ytp-ce-element",
    fallbacks: [".ytp-endscreen-content"],
    description: "End screen suggestions"
  },
  shortsInFeed: {
    primary: "ytd-reel-shelf-renderer",
    fallbacks: ["ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)"],
    description: "Shorts shelf in feed"
  },
  homeFeed: {
    primary: "ytd-rich-grid-renderer",
    fallbacks: ["#contents.ytd-rich-grid-renderer"],
    description: "Homepage video grid"
  }
};

// src/content/platforms/youtube.ts
var YouTubeContentScript = class extends PlatformContentScript {
  softBlockSelectors = [];
  disableAutoplay = true;
  shortsRedirectToWatch = true;
  constructor() {
    super("youtube");
  }
  async init() {
    const response = await sendMessage({ type: "GET_CONFIG" });
    const config = response.data;
    if (config?.platforms.youtube.softBlocks) {
      const softBlocks = config.platforms.youtube.softBlocks;
      if (softBlocks.recommendations) {
        this.softBlockSelectors.push(YOUTUBE_SELECTORS.recommendations);
      }
      if (softBlocks.endCards) {
        this.softBlockSelectors.push(YOUTUBE_SELECTORS.endCards);
      }
      if (softBlocks.shortsInFeed) {
        this.softBlockSelectors.push(YOUTUBE_SELECTORS.shortsInFeed);
      }
    }
    const customSettings = config?.platforms.youtube.customSettings;
    this.disableAutoplay = customSettings?.disableAutoplay ?? true;
    this.shortsRedirectToWatch = customSettings?.shortsRedirectToWatch ?? true;
    await super.init();
    if (this.isHomepage()) {
      this.softBlockHomepage();
    }
    if (this.disableAutoplay) {
      this.disableAutoplayToggle();
    }
    if (this.shortsRedirectToWatch) {
      this.handleShortsRedirect();
    }
  }
  isHomepage() {
    return window.location.pathname === "/" || window.location.pathname === "";
  }
  applySoftBlocks() {
    for (const selector of this.softBlockSelectors) {
      const hidden = hideAllElements(selector);
      if (hidden > 0) {
        console.log(`[IntentionalBrowsing] Hidden ${hidden} ${selector.description}`);
      }
    }
    if (this.isHomepage()) {
      this.softBlockHomepage();
    }
  }
  setupObserver() {
    const waitForBody = () => {
      if (this.softBlockSelectors.length > 0) {
        this.observer = observeAndHide(this.softBlockSelectors, document.body);
      }
      if (this.isHomepage()) {
        let scheduled = false;
        const homepageObserver = new MutationObserver(() => {
          if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(() => {
              scheduled = false;
              this.softBlockHomepage();
            });
          }
        });
        homepageObserver.observe(document.body, {
          childList: true,
          subtree: true
        });
      }
    };
    if (document.body) {
      waitForBody();
    } else {
      document.addEventListener("DOMContentLoaded", waitForBody);
    }
  }
  /**
   * Soft block the homepage - hide the video grid but keep search
   */
  softBlockHomepage() {
    const hidden = hideAllElements(YOUTUBE_SELECTORS.homeFeed);
    if (hidden > 0) {
      console.log("[IntentionalBrowsing] Hidden homepage feed");
    }
    this.addHomepageMessage();
  }
  /**
   * Add a subtle message on the homepage
   */
  addHomepageMessage() {
    const containerId = "intentional-browsing-message";
    if (document.getElementById(containerId)) {
      return;
    }
    const container = document.querySelector("#contents.ytd-rich-grid-renderer")?.parentElement;
    if (!container)
      return;
    const message = document.createElement("div");
    message.id = containerId;
    message.style.cssText = `
      text-align: center;
      padding: 40px 20px;
      color: var(--yt-spec-text-secondary, #606060);
      font-size: 14px;
    `;
    message.innerHTML = `
      <p>Homepage recommendations hidden.</p>
      <p><a href="/feed/subscriptions" style="color: var(--yt-spec-call-to-action, #065fd4);">Go to Subscriptions</a></p>
    `;
    container.prepend(message);
  }
  /**
   * Disable autoplay toggle
   */
  disableAutoplayToggle() {
    const checkAutoplay = () => {
      const toggle = document.querySelector(".ytp-autonav-toggle-button");
      if (toggle && toggle.getAttribute("aria-checked") === "true") {
        toggle.click();
        console.log("[IntentionalBrowsing] Disabled autoplay");
      }
    };
    if (document.body) {
      setTimeout(checkAutoplay, 1e3);
    }
    document.addEventListener("yt-navigate-finish", () => {
      setTimeout(checkAutoplay, 1e3);
    });
  }
  /**
   * Handle Shorts redirect to regular video
   */
  handleShortsRedirect() {
    document.addEventListener("click", (event) => {
      const link = event.target.closest('a[href*="/shorts/"]');
      if (link) {
        const href = link.getAttribute("href");
        if (href) {
          const shortId = href.split("/shorts/")[1]?.split(/[?/]/)[0];
          if (shortId) {
            event.preventDefault();
            event.stopPropagation();
            window.location.href = `/watch?v=${shortId}`;
            console.log(`[IntentionalBrowsing] Redirected short ${shortId} to watch page`);
          }
        }
      }
    }, true);
  }
};
var script = new YouTubeContentScript();
script.init().catch(console.error);
//# sourceMappingURL=youtube.js.map

// src/shared/config.ts
var SCHEMA_VERSION = 1;
var TWITTER_DEFAULT = {
  enabled: true,
  hardBlocks: {
    home: true
  },
  softBlocks: {},
  redirectTarget: "blocked"
};
var REDDIT_DEFAULT = {
  enabled: true,
  hardBlocks: {
    home: true,
    popular: true,
    all: true
  },
  softBlocks: {},
  redirectTarget: "blocked",
  customSettings: {
    blockedSubreddits: []
  }
};
var YOUTUBE_DEFAULT = {
  enabled: true,
  hardBlocks: {
    home: true,
    shorts: true,
    trending: true,
    explore: true
  },
  softBlocks: {
    recommendations: true,
    endCards: true,
    shortsInFeed: true
  },
  redirectTarget: "/feed/subscriptions",
  customSettings: {
    disableAutoplay: true,
    shortsRedirectToWatch: true
  }
};
var INSTAGRAM_DEFAULT = {
  enabled: true,
  hardBlocks: {
    home: true,
    explore: true,
    reels: true
  },
  softBlocks: {},
  redirectTarget: "/direct/inbox/"
};
var FACEBOOK_DEFAULT = {
  enabled: false,
  // Off by default
  hardBlocks: {
    watch: true,
    reels: true
  },
  softBlocks: {
    feed: true,
    stories: true,
    peopleYouMayKnow: true
  },
  redirectTarget: "/messages/"
};
var LINKEDIN_DEFAULT = {
  enabled: false,
  // Off by default
  hardBlocks: {},
  softBlocks: {
    feed: true,
    peopleYouMayKnow: true
  },
  redirectTarget: "/messaging/"
};
var TIKTOK_DEFAULT = {
  enabled: true,
  hardBlocks: {
    all: true
    // Block entire site by default
  },
  softBlocks: {},
  redirectTarget: "blocked"
};
var DEFAULT_PLATFORMS = {
  twitter: TWITTER_DEFAULT,
  reddit: REDDIT_DEFAULT,
  youtube: YOUTUBE_DEFAULT,
  instagram: INSTAGRAM_DEFAULT,
  facebook: FACEBOOK_DEFAULT,
  linkedin: LINKEDIN_DEFAULT,
  tiktok: TIKTOK_DEFAULT
};
var DEFAULT_STORAGE = {
  schemaVersion: SCHEMA_VERSION,
  globalEnabled: true,
  platforms: DEFAULT_PLATFORMS,
  pause: {
    globalUntil: null,
    platforms: {}
  },
  stats: {
    blocksTotal: 0,
    lastBlock: null
  }
};
var TWITTER_RULES = {
  hosts: ["twitter.com", "x.com", "www.twitter.com", "www.x.com", "mobile.twitter.com", "mobile.x.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "blocked", description: "Home feed" },
    { pattern: "/home", mode: "hard", redirect: "blocked", description: "Home feed (explicit)" },
    { pattern: "/explore", mode: "allow", description: "Explore page" },
    { pattern: "/explore/**", mode: "allow", description: "Explore subpages" },
    { pattern: "/search", mode: "allow", description: "Search" },
    { pattern: "/search/**", mode: "allow", description: "Search results" },
    { pattern: "/notifications", mode: "allow", description: "Notifications" },
    { pattern: "/notifications/**", mode: "allow", description: "Notification details" },
    { pattern: "/messages", mode: "allow", description: "DMs" },
    { pattern: "/messages/**", mode: "allow", description: "DM threads" },
    { pattern: "/i/**", mode: "allow", description: "Internal pages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" },
    { pattern: "/*/status/*", mode: "allow", description: "Individual tweets" },
    { pattern: "/*", mode: "allow", description: "User profiles" }
  ],
  defaultRedirect: "blocked"
};
var REDDIT_RULES = {
  hosts: ["reddit.com", "www.reddit.com", "old.reddit.com", "new.reddit.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "blocked", description: "Home feed" },
    { pattern: "/home", mode: "hard", redirect: "blocked", description: "Home feed (explicit)" },
    { pattern: "/popular", mode: "hard", redirect: "blocked", description: "Popular" },
    { pattern: "/popular/**", mode: "hard", redirect: "blocked", description: "Popular subpages" },
    { pattern: "/all", mode: "hard", redirect: "blocked", description: "r/all" },
    { pattern: "/r/all", mode: "hard", redirect: "blocked", description: "r/all (explicit)" },
    { pattern: "/r/all/**", mode: "hard", redirect: "blocked", description: "r/all subpages" },
    { pattern: "/r/popular", mode: "hard", redirect: "blocked", description: "r/popular" },
    { pattern: "/r/popular/**", mode: "hard", redirect: "blocked", description: "r/popular subpages" },
    { pattern: "/search", mode: "allow", description: "Search" },
    { pattern: "/search/**", mode: "allow", description: "Search results" },
    { pattern: "/r/*/comments/**", mode: "allow", description: "Post comments" },
    { pattern: "/r/*", mode: "allow", description: "Subreddits" },
    { pattern: "/r/**", mode: "allow", description: "Subreddit pages" },
    { pattern: "/user/*", mode: "allow", description: "User profiles" },
    { pattern: "/user/**", mode: "allow", description: "User pages" },
    { pattern: "/u/*", mode: "allow", description: "User profiles (short)" },
    { pattern: "/u/**", mode: "allow", description: "User pages (short)" },
    { pattern: "/message/**", mode: "allow", description: "Messages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" }
  ],
  defaultRedirect: "blocked"
};
var YOUTUBE_RULES = {
  hosts: ["youtube.com", "www.youtube.com", "m.youtube.com"],
  patterns: [
    { pattern: "/", mode: "soft", description: "Home (soft block, show search)" },
    { pattern: "/shorts", mode: "hard", redirect: "/feed/subscriptions", description: "Shorts tab" },
    { pattern: "/shorts/*", mode: "hard", redirect: "shorts-redirect", description: "Individual short" },
    { pattern: "/feed/trending", mode: "hard", redirect: "/feed/subscriptions", description: "Trending" },
    { pattern: "/feed/explore", mode: "hard", redirect: "/feed/subscriptions", description: "Explore" },
    { pattern: "/feed/subscriptions", mode: "allow", description: "Subscriptions" },
    { pattern: "/feed/library", mode: "allow", description: "Library" },
    { pattern: "/feed/history", mode: "allow", description: "History" },
    { pattern: "/watch", mode: "allow", description: "Video player" },
    { pattern: "/results", mode: "allow", description: "Search results" },
    { pattern: "/@*", mode: "allow", description: "Channel pages" },
    { pattern: "/channel/**", mode: "allow", description: "Channel pages (old format)" },
    { pattern: "/c/**", mode: "allow", description: "Channel pages (custom URL)" },
    { pattern: "/playlist", mode: "allow", description: "Playlists" },
    { pattern: "/premium", mode: "allow", description: "Premium page" },
    { pattern: "/account/**", mode: "allow", description: "Account settings" }
  ],
  defaultRedirect: "/feed/subscriptions"
};
var INSTAGRAM_RULES = {
  hosts: ["instagram.com", "www.instagram.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "/direct/inbox/", description: "Home feed" },
    { pattern: "/explore", mode: "hard", redirect: "/direct/inbox/", description: "Explore" },
    { pattern: "/explore/**", mode: "hard", redirect: "/direct/inbox/", description: "Explore pages" },
    { pattern: "/reels", mode: "hard", redirect: "/direct/inbox/", description: "Reels tab" },
    { pattern: "/reels/**", mode: "hard", redirect: "/direct/inbox/", description: "Individual reels" },
    { pattern: "/direct/inbox", mode: "allow", description: "DMs" },
    { pattern: "/direct/inbox/**", mode: "allow", description: "DM threads" },
    { pattern: "/direct/**", mode: "allow", description: "Direct messages" },
    { pattern: "/p/*", mode: "allow", description: "Individual posts" },
    { pattern: "/stories/**", mode: "allow", description: "Stories" },
    { pattern: "/accounts/**", mode: "allow", description: "Account settings" },
    { pattern: "/*", mode: "allow", description: "User profiles" }
  ],
  defaultRedirect: "/direct/inbox/"
};
var FACEBOOK_RULES = {
  hosts: ["facebook.com", "www.facebook.com", "m.facebook.com"],
  patterns: [
    { pattern: "/", mode: "soft", description: "Home feed (soft block)" },
    { pattern: "/watch", mode: "hard", redirect: "/messages/", description: "Watch" },
    { pattern: "/watch/**", mode: "hard", redirect: "/messages/", description: "Watch videos" },
    { pattern: "/reels", mode: "hard", redirect: "/messages/", description: "Reels" },
    { pattern: "/reels/**", mode: "hard", redirect: "/messages/", description: "Individual reels" },
    { pattern: "/marketplace", mode: "allow", description: "Marketplace" },
    { pattern: "/marketplace/**", mode: "allow", description: "Marketplace pages" },
    { pattern: "/groups/**", mode: "allow", description: "Groups" },
    { pattern: "/messages", mode: "allow", description: "Messages" },
    { pattern: "/messages/**", mode: "allow", description: "Message threads" },
    { pattern: "/events", mode: "allow", description: "Events" },
    { pattern: "/events/**", mode: "allow", description: "Event pages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" },
    { pattern: "/*", mode: "allow", description: "User profiles and pages" }
  ],
  defaultRedirect: "/messages/"
};
var LINKEDIN_RULES = {
  hosts: ["linkedin.com", "www.linkedin.com"],
  patterns: [
    { pattern: "/", mode: "soft", redirect: "/messaging/", description: "Home feed (soft block)" },
    { pattern: "/feed", mode: "soft", redirect: "/messaging/", description: "Feed (soft block)" },
    { pattern: "/feed/**", mode: "soft", redirect: "/messaging/", description: "Feed pages" },
    { pattern: "/in/*", mode: "allow", description: "User profiles" },
    { pattern: "/messaging", mode: "allow", description: "Messages" },
    { pattern: "/messaging/**", mode: "allow", description: "Message threads" },
    { pattern: "/jobs", mode: "allow", description: "Jobs" },
    { pattern: "/jobs/**", mode: "allow", description: "Job listings" },
    { pattern: "/mynetwork", mode: "allow", description: "My Network" },
    { pattern: "/mynetwork/**", mode: "allow", description: "Network pages" },
    { pattern: "/company/**", mode: "allow", description: "Company pages" },
    { pattern: "/posts/**", mode: "allow", description: "Individual posts" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" }
  ],
  defaultRedirect: "/messaging/"
};
var TIKTOK_RULES = {
  hosts: ["tiktok.com", "www.tiktok.com"],
  patterns: [
    { pattern: "/**", mode: "hard", redirect: "blocked", description: "All pages blocked" }
  ],
  defaultRedirect: "blocked"
};
var PLATFORM_RULES = {
  twitter: TWITTER_RULES,
  reddit: REDDIT_RULES,
  youtube: YOUTUBE_RULES,
  instagram: INSTAGRAM_RULES,
  facebook: FACEBOOK_RULES,
  linkedin: LINKEDIN_RULES,
  tiktok: TIKTOK_RULES
};

// src/shared/storage.ts
var STORAGE_KEY = "config";
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}
function migrateSchema(data) {
  if (!data || typeof data !== "object") {
    return deepClone(DEFAULT_STORAGE);
  }
  const obj = data;
  if (obj.schemaVersion !== SCHEMA_VERSION) {
    return deepClone(DEFAULT_STORAGE);
  }
  const result = deepClone(DEFAULT_STORAGE);
  const schema = obj;
  result.globalEnabled = schema.globalEnabled;
  result.pause = schema.pause ? deepClone(schema.pause) : result.pause;
  result.stats = schema.stats ? deepClone(schema.stats) : result.stats;
  for (const key of Object.keys(result.platforms)) {
    if (schema.platforms?.[key]) {
      result.platforms[key] = { ...result.platforms[key], ...schema.platforms[key] };
    }
  }
  return result;
}
function cleanExpiredPauses(config) {
  const now = Date.now();
  const updated = { ...config };
  if (updated.pause.globalUntil && updated.pause.globalUntil < now) {
    updated.pause = { ...updated.pause, globalUntil: null };
  }
  const platforms = { ...updated.pause.platforms };
  let platformsChanged = false;
  for (const [platform, until] of Object.entries(platforms)) {
    if (until && until < now) {
      delete platforms[platform];
      platformsChanged = true;
    }
  }
  if (platformsChanged) {
    updated.pause = { ...updated.pause, platforms };
  }
  return updated;
}
var Storage = {
  /**
   * Load configuration from storage, applying migrations and defaults
   */
  async load() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const migrated = migrateSchema(result[STORAGE_KEY]);
    const cleaned = cleanExpiredPauses(migrated);
    if (JSON.stringify(result[STORAGE_KEY]) !== JSON.stringify(cleaned)) {
      await this.save(cleaned);
    }
    return cleaned;
  },
  /**
   * Save configuration to storage
   */
  async save(config) {
    await chrome.storage.local.set({ [STORAGE_KEY]: config });
  },
  /**
   * Update a specific platform's configuration
   */
  async updatePlatform(platformId, updates) {
    const config = await this.load();
    const currentPlatform = config.platforms[platformId];
    config.platforms[platformId] = {
      ...currentPlatform,
      ...updates,
      hardBlocks: {
        ...currentPlatform.hardBlocks,
        ...updates.hardBlocks || {}
      },
      softBlocks: {
        ...currentPlatform.softBlocks,
        ...updates.softBlocks || {}
      }
    };
    await this.save(config);
    return config;
  },
  /**
   * Toggle global enabled state
   */
  async toggleGlobal(enabled) {
    const config = await this.load();
    config.globalEnabled = enabled;
    await this.save(config);
    return config;
  },
  /**
   * Set pause timer (global or per-platform)
   */
  async setPause(until, platformId) {
    const config = await this.load();
    if (platformId) {
      config.pause.platforms[platformId] = until;
    } else {
      config.pause.globalUntil = until;
    }
    await this.save(config);
    return config;
  },
  /**
   * Clear pause timer (global or per-platform)
   */
  async clearPause(platformId) {
    const config = await this.load();
    if (platformId) {
      delete config.pause.platforms[platformId];
    } else {
      config.pause.globalUntil = null;
    }
    await this.save(config);
    return config;
  },
  /**
   * Check if blocking is currently paused
   */
  isPaused(config, platformId) {
    const now = Date.now();
    if (config.pause.globalUntil && config.pause.globalUntil > now) {
      return true;
    }
    if (platformId) {
      const platformPause = config.pause.platforms[platformId];
      if (platformPause && platformPause > now) {
        return true;
      }
    }
    return false;
  },
  /**
   * Increment block count and update last block timestamp
   */
  async incrementBlockCount() {
    const config = await this.load();
    config.stats.blocksTotal += 1;
    config.stats.lastBlock = Date.now();
    await this.save(config);
    return config;
  },
  /**
   * Reset to default configuration
   */
  async reset() {
    const config = deepClone(DEFAULT_STORAGE);
    await this.save(config);
    return config;
  }
};

// src/shared/rules.ts
function matchPattern(pattern, path) {
  const normalizedPath = path.split("?")[0].replace(/\/+$/, "") || "/";
  const normalizedPattern = pattern.replace(/\/+$/, "") || "/";
  const pathSegments = normalizedPath.split("/").filter((s) => s !== "");
  const patternSegments = normalizedPattern.split("/").filter((s) => s !== "");
  if (patternSegments.length === 0 && pathSegments.length === 0) {
    return true;
  }
  return matchSegments(patternSegments, pathSegments);
}
function matchSegments(pattern, path) {
  let pi = 0;
  let si = 0;
  while (pi < pattern.length) {
    const patternSeg = pattern[pi];
    if (patternSeg === "**") {
      if (pi === pattern.length - 1) {
        return true;
      }
      for (let i = si; i <= path.length; i++) {
        if (matchSegments(pattern.slice(pi + 1), path.slice(i))) {
          return true;
        }
      }
      return false;
    }
    if (si >= path.length) {
      return false;
    }
    if (patternSeg === "*") {
      pi++;
      si++;
    } else {
      if (patternSeg !== path[si]) {
        return false;
      }
      pi++;
      si++;
    }
  }
  return si >= path.length;
}
function getPlatformFromUrl(url) {
  let hostname;
  try {
    const parsed = new URL(url);
    hostname = parsed.hostname.toLowerCase();
  } catch {
    return null;
  }
  for (const [platformId, rules] of Object.entries(PLATFORM_RULES)) {
    for (const host of rules.hosts) {
      if (host.startsWith("*.")) {
        const domain = host.slice(2);
        if (hostname === domain || hostname.endsWith("." + domain)) {
          return platformId;
        }
      } else {
        if (hostname === host) {
          return platformId;
        }
      }
    }
  }
  return null;
}
function checkUrl(url) {
  const platformId = getPlatformFromUrl(url);
  if (!platformId) {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: "Unknown platform"
    };
  }
  const rules = PLATFORM_RULES[platformId];
  let pathname;
  try {
    const parsed = new URL(url);
    pathname = parsed.pathname;
  } catch {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: "Invalid URL"
    };
  }
  for (const pattern of rules.patterns) {
    if (matchPattern(pattern.pattern, pathname)) {
      const shouldBlock = pattern.mode !== "allow";
      return {
        shouldBlock,
        mode: pattern.mode,
        redirectUrl: shouldBlock ? pattern.redirect || rules.defaultRedirect : void 0,
        reason: pattern.description
      };
    }
  }
  return {
    shouldBlock: false,
    mode: "allow",
    reason: "No matching pattern"
  };
}
function getBlockDecision(url, config) {
  if (!config.globalEnabled) {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: "Extension is globally disabled"
    };
  }
  const platformId = getPlatformFromUrl(url);
  if (!platformId) {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: "Unknown platform"
    };
  }
  const platformConfig = config.platforms[platformId];
  if (!platformConfig.enabled) {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: `${platformId} is disabled`
    };
  }
  if (Storage.isPaused(config, platformId)) {
    return {
      shouldBlock: false,
      mode: "allow",
      reason: "Blocking is paused"
    };
  }
  const baseDecision = checkUrl(url);
  if (!baseDecision.shouldBlock) {
    return baseDecision;
  }
  const rules = PLATFORM_RULES[platformId];
  let pathname;
  try {
    const parsed = new URL(url);
    pathname = parsed.pathname;
  } catch {
    return baseDecision;
  }
  for (const pattern of rules.patterns) {
    if (matchPattern(pattern.pattern, pathname) && pattern.mode === "hard") {
      const blockSetting = getHardBlockSetting(platformId, pathname);
      if (blockSetting && platformConfig.hardBlocks[blockSetting] === false) {
        return {
          shouldBlock: false,
          mode: "allow",
          reason: `Hard block '${blockSetting}' is disabled`
        };
      }
      break;
    }
  }
  return baseDecision;
}
function getHardBlockSetting(platformId, pathname) {
  const normalizedPath = pathname.replace(/\/+$/, "") || "/";
  switch (platformId) {
    case "twitter":
      if (normalizedPath === "/" || normalizedPath === "/home") {
        return "home";
      }
      if (normalizedPath.startsWith("/explore")) {
        return "explore";
      }
      break;
    case "reddit":
      if (normalizedPath === "/" || normalizedPath === "/home") {
        return "home";
      }
      if (normalizedPath === "/popular" || normalizedPath.startsWith("/popular/") || normalizedPath === "/r/popular" || normalizedPath.startsWith("/r/popular/")) {
        return "popular";
      }
      if (normalizedPath === "/all" || normalizedPath === "/r/all" || normalizedPath.startsWith("/r/all/")) {
        return "all";
      }
      break;
    case "youtube":
      if (normalizedPath === "/") {
        return "home";
      }
      if (normalizedPath === "/shorts" || normalizedPath.startsWith("/shorts/")) {
        return "shorts";
      }
      if (normalizedPath === "/feed/trending") {
        return "trending";
      }
      if (normalizedPath === "/feed/explore") {
        return "explore";
      }
      break;
    case "instagram":
      if (normalizedPath.startsWith("/explore")) {
        return "explore";
      }
      if (normalizedPath.startsWith("/reels")) {
        return "reels";
      }
      break;
    case "facebook":
      if (normalizedPath.startsWith("/watch")) {
        return "watch";
      }
      if (normalizedPath.startsWith("/reels")) {
        return "reels";
      }
      break;
    case "tiktok":
      return "all";
  }
  return null;
}

// src/mv3/background.ts
var RULE_SET_IDS = {
  twitter: "twitter_rules",
  reddit: "reddit_rules",
  youtube: "youtube_rules",
  instagram: "instagram_rules",
  facebook: "facebook_rules",
  linkedin: "linkedin_rules",
  tiktok: "tiktok_rules"
};
async function init() {
  console.log("[IntentionalBrowsing] Initializing...");
  const config = await Storage.load();
  await syncRuleStates(config);
  console.log("[IntentionalBrowsing] Initialized with config:", config.globalEnabled ? "enabled" : "disabled");
}
async function syncRuleStates(config) {
  const enableRulesetIds = [];
  const disableRulesetIds = [];
  for (const [platformId, ruleSetId] of Object.entries(RULE_SET_IDS)) {
    const platformConfig = config.platforms[platformId];
    const shouldEnable = config.globalEnabled && platformConfig.enabled;
    if (shouldEnable) {
      enableRulesetIds.push(ruleSetId);
    } else {
      disableRulesetIds.push(ruleSetId);
    }
  }
  try {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds,
      disableRulesetIds
    });
    console.log("[IntentionalBrowsing] Rule states synced");
  } catch (error) {
    console.error("[IntentionalBrowsing] Failed to sync rule states:", error);
  }
}
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    handleMessage(message).then(sendResponse).catch((error) => {
      console.error("[IntentionalBrowsing] Message handler error:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
);
async function handleMessage(message) {
  switch (message.type) {
    case "GET_CONFIG": {
      const config = await Storage.load();
      return { success: true, data: config };
    }
    case "SET_CONFIG": {
      const config = message.payload;
      await Storage.save(config);
      await syncRuleStates(config);
      return { success: true };
    }
    case "CHECK_URL": {
      const url = message.payload;
      const config = await Storage.load();
      const decision = getBlockDecision(url, config);
      return { success: true, data: decision };
    }
    case "NAVIGATE": {
      const { tabId, url } = message.payload;
      await chrome.tabs.update(tabId, { url });
      return { success: true };
    }
    case "PAUSE": {
      const { duration, platformId } = message.payload;
      const until = Date.now() + duration;
      await Storage.setPause(until, platformId);
      const config = await Storage.load();
      await syncRuleStates(config);
      return { success: true, data: { until } };
    }
    case "RESUME": {
      const { platformId } = message.payload || {};
      await Storage.clearPause(platformId);
      const config = await Storage.load();
      await syncRuleStates(config);
      return { success: true };
    }
    case "GET_STATS": {
      const config = await Storage.load();
      return { success: true, data: config.stats };
    }
    case "INCREMENT_BLOCK_COUNT": {
      await Storage.incrementBlockCount();
      return { success: true };
    }
    default:
      return { success: false, error: `Unknown message type: ${message.type}` };
  }
}
chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName === "local" && changes.config) {
    const newConfig = changes.config.newValue;
    await syncRuleStates(newConfig);
  }
});
chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);
init();
//# sourceMappingURL=background.js.map

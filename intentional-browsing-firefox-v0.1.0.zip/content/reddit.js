// src/content/router.ts
var Router = class {
  listeners = /* @__PURE__ */ new Set();
  lastUrl = "";
  originalPushState = null;
  originalReplaceState = null;
  popstateHandler = null;
  init() {
    this.lastUrl = window.location.href;
    this.patchHistory();
    this.popstateHandler = () => this.handleNavigation();
    window.addEventListener("popstate", this.popstateHandler);
    return this.lastUrl;
  }
  patchHistory() {
    this.originalPushState = history.pushState;
    this.originalReplaceState = history.replaceState;
    history.pushState = (...args) => {
      this.originalPushState.apply(history, args);
      this.handleNavigation();
    };
    history.replaceState = (...args) => {
      this.originalReplaceState.apply(history, args);
      this.handleNavigation();
    };
  }
  /**
   * Handle a navigation event
   */
  handleNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === this.lastUrl) {
      return;
    }
    this.lastUrl = currentUrl;
    for (const callback of this.listeners) {
      try {
        callback(currentUrl);
      } catch (error) {
        console.error("[IntentionalBrowsing] Router callback error:", error);
      }
    }
  }
  /**
   * Register a callback to be called when the URL changes
   */
  onLocationChange(callback) {
    this.listeners.add(callback);
  }
  /**
   * Remove a previously registered callback
   */
  removeListener(callback) {
    this.listeners.delete(callback);
  }
  /**
   * Get the current URL
   */
  getCurrentUrl() {
    return this.lastUrl || window.location.href;
  }
  /**
   * Redirect to a new URL
   */
  redirect(url) {
    window.location.href = url;
  }
  destroy() {
    if (this.originalPushState) {
      history.pushState = this.originalPushState;
    }
    if (this.originalReplaceState) {
      history.replaceState = this.originalReplaceState;
    }
    if (this.popstateHandler) {
      window.removeEventListener("popstate", this.popstateHandler);
    }
    this.listeners.clear();
  }
};
var routerInstance = null;
function getRouter() {
  if (!routerInstance) {
    routerInstance = new Router();
  }
  return routerInstance;
}

// src/content/base.ts
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function checkCurrentUrl() {
  const response = await sendMessage({
    type: "CHECK_URL",
    payload: window.location.href
  });
  if (response.success && response.data) {
    return response.data;
  }
  return { shouldBlock: false, mode: "allow" };
}
var PlatformContentScript = class {
  router;
  observer = null;
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
    this.router = getRouter();
  }
  /**
   * Initialize the content script
   */
  async init() {
    console.log(`[IntentionalBrowsing] Initializing ${this.platformId} content script`);
    this.router.init();
    const decision = await checkCurrentUrl();
    if (decision.shouldBlock) {
      if (decision.mode === "soft") {
        this.applySoftBlocks();
      }
    }
    this.router.onLocationChange(async () => {
      const newDecision = await checkCurrentUrl();
      if (newDecision.shouldBlock && newDecision.mode === "soft") {
        this.applySoftBlocks();
      }
    });
    this.setupObserver();
  }
  /**
   * Clean up
   */
  destroy() {
    this.router.destroy();
    if (this.observer) {
      this.observer.disconnect();
    }
  }
};

// src/content/platforms/reddit.ts
var RedditContentScript = class extends PlatformContentScript {
  constructor() {
    super("reddit");
  }
  applySoftBlocks() {
  }
  setupObserver() {
  }
};
var script = new RedditContentScript();
script.init().catch(console.error);
//# sourceMappingURL=reddit.js.map

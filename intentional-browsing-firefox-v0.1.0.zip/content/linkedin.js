// src/content/router.ts
var Router = class {
  listeners = /* @__PURE__ */ new Set();
  lastUrl = "";
  originalPushState = null;
  originalReplaceState = null;
  popstateHandler = null;
  init() {
    this.lastUrl = window.location.href;
    this.patchHistory();
    this.popstateHandler = () => this.handleNavigation();
    window.addEventListener("popstate", this.popstateHandler);
    return this.lastUrl;
  }
  patchHistory() {
    this.originalPushState = history.pushState;
    this.originalReplaceState = history.replaceState;
    history.pushState = (...args) => {
      this.originalPushState.apply(history, args);
      this.handleNavigation();
    };
    history.replaceState = (...args) => {
      this.originalReplaceState.apply(history, args);
      this.handleNavigation();
    };
  }
  /**
   * Handle a navigation event
   */
  handleNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === this.lastUrl) {
      return;
    }
    this.lastUrl = currentUrl;
    for (const callback of this.listeners) {
      try {
        callback(currentUrl);
      } catch (error) {
        console.error("[IntentionalBrowsing] Router callback error:", error);
      }
    }
  }
  /**
   * Register a callback to be called when the URL changes
   */
  onLocationChange(callback) {
    this.listeners.add(callback);
  }
  /**
   * Remove a previously registered callback
   */
  removeListener(callback) {
    this.listeners.delete(callback);
  }
  /**
   * Get the current URL
   */
  getCurrentUrl() {
    return this.lastUrl || window.location.href;
  }
  /**
   * Redirect to a new URL
   */
  redirect(url) {
    window.location.href = url;
  }
  destroy() {
    if (this.originalPushState) {
      history.pushState = this.originalPushState;
    }
    if (this.originalReplaceState) {
      history.replaceState = this.originalReplaceState;
    }
    if (this.popstateHandler) {
      window.removeEventListener("popstate", this.popstateHandler);
    }
    this.listeners.clear();
  }
};
var routerInstance = null;
function getRouter() {
  if (!routerInstance) {
    routerInstance = new Router();
  }
  return routerInstance;
}

// src/content/base.ts
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function checkCurrentUrl() {
  const response = await sendMessage({
    type: "CHECK_URL",
    payload: window.location.href
  });
  if (response.success && response.data) {
    return response.data;
  }
  return { shouldBlock: false, mode: "allow" };
}
function hideAllElements(selectorConfig) {
  let hiddenCount = 0;
  const primaries = document.querySelectorAll(selectorConfig.primary);
  primaries.forEach((el) => {
    el.style.display = "none";
    hiddenCount++;
  });
  if (hiddenCount > 0) {
    return hiddenCount;
  }
  for (const fallback of selectorConfig.fallbacks) {
    const elements = document.querySelectorAll(fallback);
    elements.forEach((el) => {
      el.style.display = "none";
      hiddenCount++;
    });
    if (hiddenCount > 0) {
      console.log(`[IntentionalBrowsing] Used fallback selector for ${selectorConfig.description}`);
      return hiddenCount;
    }
  }
  return hiddenCount;
}
function observeAndHide(selectorConfigs, container = document.body) {
  let scheduled = false;
  const hideElements = () => {
    scheduled = false;
    for (const config of selectorConfigs) {
      hideAllElements(config);
    }
  };
  const observer = new MutationObserver(() => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(hideElements);
    }
  });
  observer.observe(container, {
    childList: true,
    subtree: true
  });
  for (const config of selectorConfigs) {
    hideAllElements(config);
  }
  return observer;
}
var PlatformContentScript = class {
  router;
  observer = null;
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
    this.router = getRouter();
  }
  /**
   * Initialize the content script
   */
  async init() {
    console.log(`[IntentionalBrowsing] Initializing ${this.platformId} content script`);
    this.router.init();
    const decision = await checkCurrentUrl();
    if (decision.shouldBlock) {
      if (decision.mode === "soft") {
        this.applySoftBlocks();
      }
    }
    this.router.onLocationChange(async () => {
      const newDecision = await checkCurrentUrl();
      if (newDecision.shouldBlock && newDecision.mode === "soft") {
        this.applySoftBlocks();
      }
    });
    this.setupObserver();
  }
  /**
   * Clean up
   */
  destroy() {
    this.router.destroy();
    if (this.observer) {
      this.observer.disconnect();
    }
  }
};

// src/shared/config.ts
var LINKEDIN_SELECTORS = {
  feed: {
    primary: "main.scaffold-layout__main",
    fallbacks: [
      ".scaffold-finite-scroll__content",
      '[data-finite-scroll-hotkey-context="FEED"]',
      ".feed-shared-update-v2",
      '[data-id^="urn:li:activity"]'
    ],
    description: "Feed posts"
  },
  peopleYouMayKnow: {
    primary: ".mn-pymk-section",
    fallbacks: [
      '[data-test-id="people-you-may-know"]',
      ".feed-follows-module"
    ],
    description: "People you may know suggestions"
  }
};

// src/content/platforms/linkedin.ts
var LinkedInContentScript = class extends PlatformContentScript {
  softBlockSelectors = [];
  constructor() {
    super("linkedin");
  }
  async init() {
    const response = await sendMessage({ type: "GET_CONFIG" });
    const config = response.data;
    if (!config?.globalEnabled || !config?.platforms.linkedin.enabled) {
      console.log("[IntentionalBrowsing] LinkedIn blocking is disabled");
      return;
    }
    const linkedinConfig = config.platforms.linkedin;
    if (linkedinConfig.redirectTarget === "feed-block" && this.isFeedPage()) {
      console.log("[IntentionalBrowsing] LinkedIn feed-block mode active");
      this.softBlockSelectors.push(LINKEDIN_SELECTORS.feed);
      if (linkedinConfig.softBlocks?.peopleYouMayKnow) {
        this.softBlockSelectors.push(LINKEDIN_SELECTORS.peopleYouMayKnow);
      }
    }
    await super.init();
  }
  isFeedPage() {
    const path = window.location.pathname;
    return path === "/" || path === "/feed" || path.startsWith("/feed/");
  }
  applySoftBlocks() {
    for (const selector of this.softBlockSelectors) {
      const hidden = hideAllElements(selector);
      if (hidden > 0) {
        console.log(`[IntentionalBrowsing] Hidden ${hidden} ${selector.description}`);
      }
    }
    if (this.isFeedPage()) {
      this.addFeedMessage();
    }
  }
  setupObserver() {
    if (this.softBlockSelectors.length === 0) {
      return;
    }
    if (document.body) {
      this.observer = observeAndHide(this.softBlockSelectors, document.body);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        this.observer = observeAndHide(this.softBlockSelectors, document.body);
      });
    }
  }
  /**
   * Add a message on the feed page
   */
  addFeedMessage() {
    const containerId = "intentional-browsing-message";
    if (document.getElementById(containerId)) {
      return;
    }
    const feed = document.querySelector(".scaffold-finite-scroll__content");
    if (!feed)
      return;
    const message = document.createElement("div");
    message.id = containerId;
    message.style.cssText = `
      text-align: center;
      padding: 40px 20px;
      color: rgba(0, 0, 0, 0.6);
      font-size: 14px;
      background: #fff;
      border-radius: 8px;
      margin: 8px 0;
      box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.08);
    `;
    message.innerHTML = `
      <p>Feed hidden.</p>
      <p><a href="/messaging/" style="color: #0a66c2;">Go to Messages</a></p>
    `;
    feed.parentElement?.insertBefore(message, feed);
  }
};
var script = new LinkedInContentScript();
script.init().catch(console.error);
//# sourceMappingURL=linkedin.js.map

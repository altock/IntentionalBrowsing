// src/content/router.ts
var Router = class {
  listeners = /* @__PURE__ */ new Set();
  lastUrl = "";
  originalPushState = null;
  originalReplaceState = null;
  popstateHandler = null;
  init() {
    this.lastUrl = window.location.href;
    this.patchHistory();
    this.popstateHandler = () => this.handleNavigation();
    window.addEventListener("popstate", this.popstateHandler);
    return this.lastUrl;
  }
  patchHistory() {
    this.originalPushState = history.pushState;
    this.originalReplaceState = history.replaceState;
    history.pushState = (...args) => {
      this.originalPushState.apply(history, args);
      this.handleNavigation();
    };
    history.replaceState = (...args) => {
      this.originalReplaceState.apply(history, args);
      this.handleNavigation();
    };
  }
  /**
   * Handle a navigation event
   */
  handleNavigation() {
    const currentUrl = window.location.href;
    if (currentUrl === this.lastUrl) {
      return;
    }
    this.lastUrl = currentUrl;
    for (const callback of this.listeners) {
      try {
        callback(currentUrl);
      } catch (error) {
        console.error("[IntentionalBrowsing] Router callback error:", error);
      }
    }
  }
  /**
   * Register a callback to be called when the URL changes
   */
  onLocationChange(callback) {
    this.listeners.add(callback);
  }
  /**
   * Remove a previously registered callback
   */
  removeListener(callback) {
    this.listeners.delete(callback);
  }
  /**
   * Get the current URL
   */
  getCurrentUrl() {
    return this.lastUrl || window.location.href;
  }
  /**
   * Redirect to a new URL
   */
  redirect(url) {
    window.location.href = url;
  }
  destroy() {
    if (this.originalPushState) {
      history.pushState = this.originalPushState;
    }
    if (this.originalReplaceState) {
      history.replaceState = this.originalReplaceState;
    }
    if (this.popstateHandler) {
      window.removeEventListener("popstate", this.popstateHandler);
    }
    this.listeners.clear();
  }
};
var routerInstance = null;
function getRouter() {
  if (!routerInstance) {
    routerInstance = new Router();
  }
  return routerInstance;
}

// src/content/base.ts
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function checkCurrentUrl() {
  const response = await sendMessage({
    type: "CHECK_URL",
    payload: window.location.href
  });
  if (response.success && response.data) {
    return response.data;
  }
  return { shouldBlock: false, mode: "allow" };
}
function hideAllElements(selectorConfig) {
  let hiddenCount = 0;
  const primaries = document.querySelectorAll(selectorConfig.primary);
  primaries.forEach((el) => {
    el.style.display = "none";
    hiddenCount++;
  });
  if (hiddenCount > 0) {
    return hiddenCount;
  }
  for (const fallback of selectorConfig.fallbacks) {
    const elements = document.querySelectorAll(fallback);
    elements.forEach((el) => {
      el.style.display = "none";
      hiddenCount++;
    });
    if (hiddenCount > 0) {
      console.log(`[IntentionalBrowsing] Used fallback selector for ${selectorConfig.description}`);
      return hiddenCount;
    }
  }
  return hiddenCount;
}
function observeAndHide(selectorConfigs, container = document.body) {
  let scheduled = false;
  const hideElements = () => {
    scheduled = false;
    for (const config of selectorConfigs) {
      hideAllElements(config);
    }
  };
  const observer = new MutationObserver(() => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(hideElements);
    }
  });
  observer.observe(container, {
    childList: true,
    subtree: true
  });
  for (const config of selectorConfigs) {
    hideAllElements(config);
  }
  return observer;
}
var PlatformContentScript = class {
  router;
  observer = null;
  platformId;
  constructor(platformId) {
    this.platformId = platformId;
    this.router = getRouter();
  }
  /**
   * Initialize the content script
   */
  async init() {
    console.log(`[IntentionalBrowsing] Initializing ${this.platformId} content script`);
    this.router.init();
    const decision = await checkCurrentUrl();
    if (decision.shouldBlock) {
      if (decision.mode === "soft") {
        this.applySoftBlocks();
      }
    }
    this.router.onLocationChange(async () => {
      const newDecision = await checkCurrentUrl();
      if (newDecision.shouldBlock && newDecision.mode === "soft") {
        this.applySoftBlocks();
      }
    });
    this.setupObserver();
  }
  /**
   * Clean up
   */
  destroy() {
    this.router.destroy();
    if (this.observer) {
      this.observer.disconnect();
    }
  }
};

// src/shared/config.ts
var FACEBOOK_SELECTORS = {
  feed: {
    primary: '[role="feed"]',
    fallbacks: ['[data-pagelet="FeedUnit"]'],
    description: "News feed"
  },
  stories: {
    primary: '[data-pagelet="Stories"]',
    fallbacks: ['[aria-label*="Stories"]'],
    description: "Stories tray"
  },
  peopleYouMayKnow: {
    primary: '[data-pagelet="RightRail"] [aria-label*="People"]',
    fallbacks: [],
    description: "People you may know suggestions"
  }
};

// src/content/platforms/facebook.ts
var FacebookContentScript = class extends PlatformContentScript {
  softBlockSelectors = [];
  constructor() {
    super("facebook");
  }
  async init() {
    const response = await sendMessage({ type: "GET_CONFIG" });
    const config = response.data;
    if (!config?.platforms.facebook.enabled) {
      console.log("[IntentionalBrowsing] Facebook blocking is disabled");
      return;
    }
    if (config?.platforms.facebook.softBlocks) {
      const softBlocks = config.platforms.facebook.softBlocks;
      if (softBlocks.feed && this.isHomepage()) {
        this.softBlockSelectors.push(FACEBOOK_SELECTORS.feed);
      }
      if (softBlocks.stories) {
        this.softBlockSelectors.push(FACEBOOK_SELECTORS.stories);
      }
      if (softBlocks.peopleYouMayKnow) {
        this.softBlockSelectors.push(FACEBOOK_SELECTORS.peopleYouMayKnow);
      }
    }
    await super.init();
  }
  isHomepage() {
    return window.location.pathname === "/" || window.location.pathname === "";
  }
  applySoftBlocks() {
    for (const selector of this.softBlockSelectors) {
      const hidden = hideAllElements(selector);
      if (hidden > 0) {
        console.log(`[IntentionalBrowsing] Hidden ${hidden} ${selector.description}`);
      }
    }
    if (this.isHomepage()) {
      this.addHomepageMessage();
    }
  }
  setupObserver() {
    if (this.softBlockSelectors.length === 0) {
      return;
    }
    if (document.body) {
      this.observer = observeAndHide(this.softBlockSelectors, document.body);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        this.observer = observeAndHide(this.softBlockSelectors, document.body);
      });
    }
  }
  /**
   * Add a message on the homepage
   */
  addHomepageMessage() {
    const containerId = "intentional-browsing-message";
    if (document.getElementById(containerId)) {
      return;
    }
    const feed = document.querySelector('[role="feed"]');
    if (!feed)
      return;
    const message = document.createElement("div");
    message.id = containerId;
    message.style.cssText = `
      text-align: center;
      padding: 40px 20px;
      color: #65676b;
      font-size: 14px;
      background: #f0f2f5;
      border-radius: 8px;
      margin: 16px;
    `;
    message.innerHTML = `
      <p>News Feed hidden.</p>
      <p><a href="/messages/" style="color: #1877f2;">Go to Messages</a></p>
    `;
    feed.parentElement?.insertBefore(message, feed);
  }
};
var script = new FacebookContentScript();
script.init().catch(console.error);
//# sourceMappingURL=facebook.js.map

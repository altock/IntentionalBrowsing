// src/ui/popup.ts
var PLATFORM_NAMES = {
  twitter: "X / Twitter",
  reddit: "Reddit",
  youtube: "YouTube",
  instagram: "Instagram",
  facebook: "Facebook",
  linkedin: "LinkedIn",
  tiktok: "TikTok"
};
var PLATFORM_ORDER = [
  "twitter",
  "reddit",
  "youtube",
  "instagram",
  "facebook",
  "linkedin",
  "tiktok"
];
var currentConfig = null;
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response || { success: false, error: "No response" });
    });
  });
}
async function loadConfig() {
  const response = await sendMessage({ type: "GET_CONFIG" });
  if (response.success && response.data) {
    currentConfig = response.data;
    return response.data;
  }
  return null;
}
async function saveConfig(config) {
  await sendMessage({ type: "SET_CONFIG", payload: config });
  currentConfig = config;
}
function render(config) {
  const popup = document.querySelector(".popup");
  const globalToggle = document.getElementById("global-enabled");
  const platformsContainer = document.getElementById("platforms");
  const statsContainer = document.getElementById("stats");
  globalToggle.checked = config.globalEnabled;
  popup.classList.toggle("disabled", !config.globalEnabled);
  platformsContainer.innerHTML = PLATFORM_ORDER.map((platformId) => {
    const platformConfig = config.platforms[platformId];
    return `
      <div class="platform" data-platform="${platformId}">
        <div class="platform-info">
          <span class="platform-name">${PLATFORM_NAMES[platformId]}</span>
        </div>
        <div class="platform-controls">
          <label class="platform-toggle">
            <input type="checkbox" data-platform="${platformId}" ${platformConfig.enabled ? "checked" : ""}>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    `;
  }).join("");
  statsContainer.textContent = `Blocked ${config.stats.blocksTotal} distractions`;
}
async function handleGlobalToggle(enabled) {
  if (!currentConfig)
    return;
  currentConfig.globalEnabled = enabled;
  await saveConfig(currentConfig);
  render(currentConfig);
}
async function handlePlatformToggle(platformId, enabled) {
  if (!currentConfig)
    return;
  currentConfig.platforms[platformId].enabled = enabled;
  await saveConfig(currentConfig);
  render(currentConfig);
}
function setupEventListeners() {
  document.getElementById("global-enabled")?.addEventListener("change", (e) => {
    const target = e.target;
    handleGlobalToggle(target.checked);
  });
  document.getElementById("platforms")?.addEventListener("change", (e) => {
    const target = e.target;
    if (target.dataset.platform) {
      handlePlatformToggle(target.dataset.platform, target.checked);
    }
  });
}
async function init() {
  setupEventListeners();
  const config = await loadConfig();
  if (config) {
    render(config);
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
//# sourceMappingURL=popup.js.map

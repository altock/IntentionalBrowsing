// src/shared/config.ts
var TWITTER_RULES = {
  hosts: ["twitter.com", "x.com", "www.twitter.com", "www.x.com", "mobile.twitter.com", "mobile.x.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "blocked", description: "Home feed" },
    { pattern: "/home", mode: "hard", redirect: "blocked", description: "Home feed (explicit)" },
    { pattern: "/explore", mode: "allow", description: "Explore page" },
    { pattern: "/explore/**", mode: "allow", description: "Explore subpages" },
    { pattern: "/search", mode: "allow", description: "Search" },
    { pattern: "/search/**", mode: "allow", description: "Search results" },
    { pattern: "/notifications", mode: "allow", description: "Notifications" },
    { pattern: "/notifications/**", mode: "allow", description: "Notification details" },
    { pattern: "/messages", mode: "allow", description: "DMs" },
    { pattern: "/messages/**", mode: "allow", description: "DM threads" },
    { pattern: "/i/**", mode: "allow", description: "Internal pages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" },
    { pattern: "/*/status/*", mode: "allow", description: "Individual tweets" },
    { pattern: "/*", mode: "allow", description: "User profiles" }
  ],
  defaultRedirect: "blocked"
};
var REDDIT_RULES = {
  hosts: ["reddit.com", "www.reddit.com", "old.reddit.com", "new.reddit.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "blocked", description: "Home feed" },
    { pattern: "/home", mode: "hard", redirect: "blocked", description: "Home feed (explicit)" },
    { pattern: "/popular", mode: "hard", redirect: "blocked", description: "Popular" },
    { pattern: "/popular/**", mode: "hard", redirect: "blocked", description: "Popular subpages" },
    { pattern: "/all", mode: "hard", redirect: "blocked", description: "r/all" },
    { pattern: "/r/all", mode: "hard", redirect: "blocked", description: "r/all (explicit)" },
    { pattern: "/r/all/**", mode: "hard", redirect: "blocked", description: "r/all subpages" },
    { pattern: "/r/popular", mode: "hard", redirect: "blocked", description: "r/popular" },
    { pattern: "/r/popular/**", mode: "hard", redirect: "blocked", description: "r/popular subpages" },
    { pattern: "/search", mode: "allow", description: "Search" },
    { pattern: "/search/**", mode: "allow", description: "Search results" },
    { pattern: "/r/*/comments/**", mode: "allow", description: "Post comments" },
    { pattern: "/r/*", mode: "allow", description: "Subreddits" },
    { pattern: "/r/**", mode: "allow", description: "Subreddit pages" },
    { pattern: "/user/*", mode: "allow", description: "User profiles" },
    { pattern: "/user/**", mode: "allow", description: "User pages" },
    { pattern: "/u/*", mode: "allow", description: "User profiles (short)" },
    { pattern: "/u/**", mode: "allow", description: "User pages (short)" },
    { pattern: "/message/**", mode: "allow", description: "Messages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" }
  ],
  defaultRedirect: "blocked"
};
var YOUTUBE_RULES = {
  hosts: ["youtube.com", "www.youtube.com", "m.youtube.com"],
  patterns: [
    { pattern: "/", mode: "soft", description: "Home (soft block, show search)" },
    { pattern: "/shorts", mode: "hard", redirect: "/feed/subscriptions", description: "Shorts tab" },
    { pattern: "/shorts/*", mode: "hard", redirect: "shorts-redirect", description: "Individual short" },
    { pattern: "/feed/trending", mode: "hard", redirect: "/feed/subscriptions", description: "Trending" },
    { pattern: "/feed/explore", mode: "hard", redirect: "/feed/subscriptions", description: "Explore" },
    { pattern: "/feed/subscriptions", mode: "allow", description: "Subscriptions" },
    { pattern: "/feed/library", mode: "allow", description: "Library" },
    { pattern: "/feed/history", mode: "allow", description: "History" },
    { pattern: "/watch", mode: "allow", description: "Video player" },
    { pattern: "/results", mode: "allow", description: "Search results" },
    { pattern: "/@*", mode: "allow", description: "Channel pages" },
    { pattern: "/channel/**", mode: "allow", description: "Channel pages (old format)" },
    { pattern: "/c/**", mode: "allow", description: "Channel pages (custom URL)" },
    { pattern: "/playlist", mode: "allow", description: "Playlists" },
    { pattern: "/premium", mode: "allow", description: "Premium page" },
    { pattern: "/account/**", mode: "allow", description: "Account settings" }
  ],
  defaultRedirect: "/feed/subscriptions"
};
var INSTAGRAM_RULES = {
  hosts: ["instagram.com", "www.instagram.com"],
  patterns: [
    { pattern: "/", mode: "hard", redirect: "/direct/inbox/", description: "Home feed" },
    { pattern: "/explore", mode: "hard", redirect: "/direct/inbox/", description: "Explore" },
    { pattern: "/explore/**", mode: "hard", redirect: "/direct/inbox/", description: "Explore pages" },
    { pattern: "/reels", mode: "hard", redirect: "/direct/inbox/", description: "Reels tab" },
    { pattern: "/reels/**", mode: "hard", redirect: "/direct/inbox/", description: "Individual reels" },
    { pattern: "/direct/inbox", mode: "allow", description: "DMs" },
    { pattern: "/direct/inbox/**", mode: "allow", description: "DM threads" },
    { pattern: "/direct/**", mode: "allow", description: "Direct messages" },
    { pattern: "/p/*", mode: "allow", description: "Individual posts" },
    { pattern: "/stories/**", mode: "allow", description: "Stories" },
    { pattern: "/accounts/**", mode: "allow", description: "Account settings" },
    { pattern: "/*", mode: "allow", description: "User profiles" }
  ],
  defaultRedirect: "/direct/inbox/"
};
var FACEBOOK_RULES = {
  hosts: ["facebook.com", "www.facebook.com", "m.facebook.com"],
  patterns: [
    { pattern: "/", mode: "soft", description: "Home feed (soft block)" },
    { pattern: "/watch", mode: "hard", redirect: "/messages/", description: "Watch" },
    { pattern: "/watch/**", mode: "hard", redirect: "/messages/", description: "Watch videos" },
    { pattern: "/reels", mode: "hard", redirect: "/messages/", description: "Reels" },
    { pattern: "/reels/**", mode: "hard", redirect: "/messages/", description: "Individual reels" },
    { pattern: "/marketplace", mode: "allow", description: "Marketplace" },
    { pattern: "/marketplace/**", mode: "allow", description: "Marketplace pages" },
    { pattern: "/groups/**", mode: "allow", description: "Groups" },
    { pattern: "/messages", mode: "allow", description: "Messages" },
    { pattern: "/messages/**", mode: "allow", description: "Message threads" },
    { pattern: "/events", mode: "allow", description: "Events" },
    { pattern: "/events/**", mode: "allow", description: "Event pages" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" },
    { pattern: "/*", mode: "allow", description: "User profiles and pages" }
  ],
  defaultRedirect: "/messages/"
};
var LINKEDIN_RULES = {
  hosts: ["linkedin.com", "www.linkedin.com"],
  patterns: [
    { pattern: "/", mode: "soft", redirect: "/messaging/", description: "Home feed (soft block)" },
    { pattern: "/feed", mode: "soft", redirect: "/messaging/", description: "Feed (soft block)" },
    { pattern: "/feed/**", mode: "soft", redirect: "/messaging/", description: "Feed pages" },
    { pattern: "/in/*", mode: "allow", description: "User profiles" },
    { pattern: "/messaging", mode: "allow", description: "Messages" },
    { pattern: "/messaging/**", mode: "allow", description: "Message threads" },
    { pattern: "/jobs", mode: "allow", description: "Jobs" },
    { pattern: "/jobs/**", mode: "allow", description: "Job listings" },
    { pattern: "/mynetwork", mode: "allow", description: "My Network" },
    { pattern: "/mynetwork/**", mode: "allow", description: "Network pages" },
    { pattern: "/company/**", mode: "allow", description: "Company pages" },
    { pattern: "/posts/**", mode: "allow", description: "Individual posts" },
    { pattern: "/settings/**", mode: "allow", description: "Settings" }
  ],
  defaultRedirect: "/messaging/"
};
var TIKTOK_RULES = {
  hosts: ["tiktok.com", "www.tiktok.com"],
  patterns: [
    { pattern: "/**", mode: "hard", redirect: "blocked", description: "All pages blocked" }
  ],
  defaultRedirect: "blocked"
};
var PLATFORM_RULES = {
  twitter: TWITTER_RULES,
  reddit: REDDIT_RULES,
  youtube: YOUTUBE_RULES,
  instagram: INSTAGRAM_RULES,
  facebook: FACEBOOK_RULES,
  linkedin: LINKEDIN_RULES,
  tiktok: TIKTOK_RULES
};

// src/shared/rules.ts
function getPlatformFromUrl(url) {
  let hostname;
  try {
    const parsed = new URL(url);
    hostname = parsed.hostname.toLowerCase();
  } catch {
    return null;
  }
  for (const [platformId, rules] of Object.entries(PLATFORM_RULES)) {
    for (const host of rules.hosts) {
      if (host.startsWith("*.")) {
        const domain = host.slice(2);
        if (hostname === domain || hostname.endsWith("." + domain)) {
          return platformId;
        }
      } else {
        if (hostname === host) {
          return platformId;
        }
      }
    }
  }
  return null;
}

// src/ui/blocked.ts
function init() {
  const params = new URLSearchParams(window.location.search);
  const blockedUrl = params.get("url");
  if (blockedUrl) {
    const platformId = getPlatformFromUrl(blockedUrl);
    const subtitle = document.getElementById("subtitle");
    if (subtitle && platformId) {
      subtitle.textContent = `You tried to access ${platformId}.`;
    }
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
//# sourceMappingURL=blocked.js.map
